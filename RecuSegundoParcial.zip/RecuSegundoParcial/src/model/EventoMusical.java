package model;

import java.io.Serializable;
import java.time.LocalDate;
import service.CSVSerializable;
import service.GestorEventos;


public class EventoMusical extends evento implements Comparable<EventoMusical>,CSVSerializable,Serializable{
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre,LocalDate fecha,String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public String toString() {
        return super.toString() + "artista: " + artista + ", genero: " + genero + '}';
    }

    @Override
    public int compareTo(EventoMusical o) {
         return this.getFecha().compareTo(o.getFecha());
    }

    @Override
    public String toCSV(){
        return getId() + "," + getNombre() + "," + getFecha()+ "," + getArtista() + "," + genero.toString();
    }
    
    public static EventoMusical fromCSV(String EventoMusicalCSV){
        if(EventoMusicalCSV.endsWith("\n")){
            EventoMusicalCSV = EventoMusicalCSV.substring(0,EventoMusicalCSV.length()-1);
        }
        String[] valores = EventoMusicalCSV.split(",");
        return new EventoMusical(Integer.parseInt(valores[0]),
                valores[1],
                LocalDate.parse(valores[2]),
                valores[3],
                GeneroMusical.valueOf(valores[4]));
    }
    
}
