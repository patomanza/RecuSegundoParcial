package model;

public enum GeneroMusical {
     ROCK, POP, JAZZ, CLASICA, ELECTRONICA;
}
