package service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Almacenable<T extends CSVSerializable>{
    
    void agregar(T item);
    
    T obtener(int indice);
    
    void eliminar(int indice);
    
    List<T> filtrar(Predicate<T> predicado);
    
    List<T> BuscarPorRango(LocalDate fecha1, LocalDate fecha2);
    
    void ordenar();
    
    void ordenar(Comparator<T> comparador);
    
    void serializar(String path);
    
    void deserealizar(String path);
    
    void guardarCSV(String path);
    
    void cargarCSV(String path, Function<String,T> funcion);
    
}
